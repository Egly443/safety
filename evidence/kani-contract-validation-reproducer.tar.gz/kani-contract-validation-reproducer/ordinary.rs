
fn constant() -> bool { true }

#[kani::proof]
fn check_constant() { assert!(constant()); }
